Faris (cvsuhail-faris) - ARML font

cvsuhail-faris draws ARML text: the pre-shaped, visual-order legacy encoding for Arabi-Malayalam.
Type or convert text at https://arabi-malayalam.cvsuhail.online/ and use "Copy as ARML",
then paste it where this font is applied. The encoding is described in ARML-SPEC.md,
included in this archive.

Notes
- Latin letters share codes with ARML glyphs, so give Latin text a Latin font.
- Vowel marks use GPOS mark-to-base positioning. Programs that ignore it draw them off-centre.
- Keep one line per text box: lines are stored in drawing order and must not be re-wrapped.

Licence
This font is a modified version of ReemKufi, renamed as the SIL Open Font License 1.1
requires. It is free to use, study, copy, modify and redistribute under that licence.
It must not be sold by itself. The licence text of the original font is in
OFL-reemkufi.txt. Please keep it with the font.
